
/**
 * Especificação do tipo de dados CartaoPontos
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface CartaoPontos
{
    public void setPontos(int pontos);
    public int getPontos();
}
