
/**
 * Write a description of class HotelInexistenteException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HotelInexistenteException extends Exception
{
    public HotelInexistenteException() {
        super();
    } 
    public HotelInexistenteException(String message) {
        super(message);
    }    
}
